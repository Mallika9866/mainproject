const form = document.querySelector('form');

form.addEventListener('submit', (event) => {
    event.preventDefault();
    // Handle form submission logic here
});